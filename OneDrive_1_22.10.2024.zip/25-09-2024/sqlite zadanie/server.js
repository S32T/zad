const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 3000;

// Utworzenie lub otwarcie bazy danych SQLite
const db = new sqlite3.Database('nodebaza.db', (err) => {
  if (err) {
    console.error('Błąd przy otwieraniu bazy danych:', err);
  } else {
    console.log('Połączono z bazą danych SQLite.');

    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      fname TEXT,
      lname TEXT
    )`);
  }
});

// Middleware do parsowania danych z formularza
app.use(bodyParser.urlencoded({ extended: true }));

// Serwowanie plików statycznych (CSS, obrazy itp.)
app.use(express.static('public'));

// Serwowanie pliku HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/submit', (req, res) => {
    const { fname, lname } = req.body;
  
    const sql = "INSERT INTO users (fname, lname) VALUES (?, ?)";
    db.run(sql, [fname, lname], function(err) {
      if (err) {
        console.error('Błąd przy zapisie do bazy danych:', err);
        res.send('Wystąpił błąd przy zapisie do bazy danych.');
      } else {
        console.log('Dane zapisane do bazy danych:', { id: this.lastID });
        res.send(`
          <html>
          <head>
            <link rel="stylesheet" href="style.css">
          </head>
          <body>
            <div class="container">
              <h1>Dziękujemy!</h1>
              <div class="message">
                Dziękujemy, ${fname}! Twoje dane zostały zapisane do bazy.
              </div>
              <div class="user-list-link">
                <a href="/users">Zobacz listę użytkowników</a>
              </div>
              <div class="user-list-link">
                <a href="/">Powrót do formularza</a>
              </div>
            </div>
          </body>
          </html>
        `);
      }
    });
  });

  app.get('/users', (req, res) => {
    const sql = "SELECT * FROM users";
    db.all(sql, [], (err, rows) => {
      if (err) {
        console.error('Błąd przy pobieraniu danych z bazy:', err);
        res.send('Wystąpił błąd przy pobieraniu danych z bazy.');
      } else {
        res.send(`
          <html>
          <head>
            <link rel="stylesheet" href="style.css">
          </head>
          <body>
            <div class="container">
              <h1>Lista użytkowników</h1>
              <ul>
                ${rows.map(row => `<li>${row.fname} (${row.lname})</li>`).join('')}
              </ul>
              <a href="/">Powrót do formularza</a>
            </div>
          </body>
          </html>
        `);
      }
    });
  });
  

// Uruchomienie serwera
app.listen(port, () => {
  console.log(`Serwer działa na http://localhost:${port}`);
});
