var readline = require('readline'); // moduł readline

var r1 = readline.createInterface({ // tworzenie interfejsu
    input : process.stdin,
    output: process.stdout  
});

r1.question('Jak masz na imię?\n',function(answer){ // zapytanie
    r1.question('Jaki jest twój ulubiony język programowania '+answer+'?\n',function(language){
        r1.question('Ile lat programujesz?\n',function(time){
            console.log(answer+'\n'+language+'\n'+time);
        });
    });
});