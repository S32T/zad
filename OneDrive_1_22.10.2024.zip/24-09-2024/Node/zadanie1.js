var readline = require("readline");

var r1 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

r1.question("Podaj ciąg znaków: ",(odp) => {
    console.log("Podany ciąg to: "+odp);
    r1.close();
})