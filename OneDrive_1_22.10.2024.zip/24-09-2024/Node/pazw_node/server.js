const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

// Konfiguracja połączenia z bazą danych MySQL
const db = mysql.createConnection({
    host: 'localhost',  // lub inny host, jeśli masz zdalną bazę
    user: 'root',       // nazwa użytkownika MySQL
    password: '',       // hasło użytkownika MySQL
    database: 'form' // nazwa bazy danych
  });

// Połączenie z bazą
db.connect((err) => {
    if (err) {
      console.error('Błąd połączenia z bazą danych: ', err);
    } else {
      console.log('Połączono z bazą danych MySQL.');
    }
  });

// Middleware do parsowania danych z formularza
app.use(bodyParser.urlencoded({ extended: true }));

// Serwowanie pliku HTML przy żądaniu GET /
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Obsługa formularza i wyświetlanie danych w konsoli
app.post('/submit', (req, res) => {
    const { fname, lname } = req.body;

    const sql = "INSERT INTO users (fname, lname) VALUES (?, ?)";
    db.query(sql, [fname, lname], (err, result) => {
      if (err) {
        console.error('Błąd przy zapisie do bazy danych: ', err);
        res.send('Wystąpił błąd przy zapisie do bazy danych.');
      } else {
        console.log('Dane zapisane do bazy danych: ', result);
        res.send(`Dziękujemy, ${fname}! Twoje dane zostały zapisane.`);
      }
    });
  });

// Uruchomienie serwera
app.listen(port, () => {
    console.log(`Serwer działa na http://localhost:${port}`);
});
